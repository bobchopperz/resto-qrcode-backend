// This file is the entry point for cPanel. It bridges to the actual NestJS application.
require('./dist/main.js');
